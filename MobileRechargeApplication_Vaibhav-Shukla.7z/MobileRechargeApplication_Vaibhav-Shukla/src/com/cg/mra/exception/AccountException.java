package com.cg.mra.exception;

//creating exception class
public class AccountException extends Exception {

	// creating constructor of exception class
	public AccountException(String message) {

		super(message);
	}

}
